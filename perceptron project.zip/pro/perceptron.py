import numpy as np
import pandas as pd


def sigmoid(z):
    return 1.0/(1.0+np.exp(-z))


def feedforward(x, w, th):
    a = sigmoid(np.dot(w, x) + th)
    return a


def predict(x, w, th):
    #x = x.reshape(-1, 1)
    a = feedforward(x, w, th)
    if(a>0.5):
        return 1
    return 0


#reading data and spliting it to train and test set
dataSet = pd.read_csv('IRIS2.csv').sample(frac=1) #reading and shuffling data 
selected = np.random.rand(len(dataSet)) < 0.70

train = dataSet[selected]
test = dataSet[~selected]


train_y = train['species'].values
test_y = test['species'].values

train_x = train.drop(columns = ['species']).values
test_x = test.drop(columns = ['species']).values


# initializing weight vector
input_size = len(train_x[0])
w = np.zeros((1, input_size))
th = 0                                   # thershold value
epochs = 20
a = 0.1                                   # learning rate 


def mainFunction(X, Y, w, th, a, epochs):
    for t in range(epochs):
        for i in range(len(X)):
            x, y = X[i], Y[i]
            y_pred = feedforward(x, w, th)
            w = w + a*(y - y_pred)*X[i]
            th = th + a*(y - y_pred)   
            #print('weight\t', w, ' thershold' ,th,'epoch', t)
    return w, th



# using mainFunction to train the perceptron on training dataset
w, th = mainFunction(train_x, train_y, w, th, a, epochs)

# Using perceptron to predict for test dataset
print('True label\t', 'predicted label')
for i in range(len(test_x)):
    x = test_x[i] 
    y = test_y[i]
    y_pred = predict(x, w, th)
    print(y, '\t\t\t', y_pred)